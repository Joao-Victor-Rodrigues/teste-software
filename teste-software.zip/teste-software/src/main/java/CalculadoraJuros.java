public class CalculadoraJuros {
    
    public int calcularJurosSimples(double capital, double taxa, int tempo) {
        throw new UnsupportedOperationException("Método não implementado");
    }
}
